package adapter;

import exception.AutoException;

public interface AutoThread {
	public void updateOptionName(String threadName,String autoID, String setName,String oldName, String newName);
}
