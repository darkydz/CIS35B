package adapter;
/**
 * This class will always be empty
 * @author anguyen
 *
 */
public class BuildAuto extends ProxyAutomobile implements CreateAuto, UpdateAuto, FixAuto, AutoChoice, AutoThread {
}
