package adapter;

import exception.AutoException;

public interface CreateAuto {
	public void buildAuto(String filename);
	public void printAuto(String autoID);
}
